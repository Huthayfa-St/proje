﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Webodev.Data.Migrations
{
    public partial class ApplicationDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ProductTypes",
                table: "ProductTypes");

            migrationBuilder.RenameTable(
                name: "ProductTypes",
                newName: "ProductTypesController");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ProductTypesController",
                table: "ProductTypesController",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_ProductTypesController",
                table: "ProductTypesController");

            migrationBuilder.RenameTable(
                name: "ProductTypesController",
                newName: "ProductTypes");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ProductTypes",
                table: "ProductTypes",
                column: "Id");
        }
    }
}
