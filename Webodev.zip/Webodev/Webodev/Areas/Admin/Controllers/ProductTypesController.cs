﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Webodev.Data;
using System.Threading.Tasks;
using System.Web.WebPages.Html;
using Webodev.Models;
using System;
using Microsoft.EntityFrameworkCore;

namespace Webodev.Areas.Admin.Controllers
{
    [Area("Admin")]

    public class ProductTypesController : Controller
    {

        private ApplicationDbContext _db;
        public ProductTypesController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            //var data = _db.ProductTypes.ToList();
          return View(_db.ProductTypesController.ToList());
        }



        // Get Create action Method 
        public ActionResult Create()
        {
            return View();
        }
        //Create Post Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductTypes productTypes)
        {

            if (ModelState.IsValid)
            {
             //   _db.Add(productTypes);
                _db.ProductTypesController.Add(productTypes);
                await _db.SaveChangesAsync();
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(productTypes);
        }
        /// <summary>
        /// ///////////////

        // Get Edit action Method 
        public ActionResult Edit(int ?id)
        {
            if(id==null)
            {
                return NotFound();
            }
            var productType = _db.ProductTypesController.Find(id);
            if(productType==null)
            {
                return NotFound();
            }
            return View(productType);
        }
        //Post Edit  Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductTypes productTypes)
        {

            if (ModelState.IsValid)
            {
                //   _db.Add(productTypes);
                _db.ProductTypesController.Update(productTypes);
                await _db.SaveChangesAsync();
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(productTypes);
        }
        ///////////////////////////////////////
        ///
                //Get Details  action Method 
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var productType = _db.ProductTypesController.Find(id);
            if (productType == null)
            {
                return NotFound();
            }
            return View(productType);
        }
        //Post Details  Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Details(ProductTypes productTypes)
        {
                return RedirectToAction(actionName: nameof(Index));
        }
        ///////////////////////
        ///
        // Get Delete action Method 
      
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var productType = _db.ProductTypesController.Find(id);
            if (productType == null)
            {
                return NotFound();
            }
            return View(productType);
        }
        //Post Delete  Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int? id,ProductTypes productTypes)
        {


        if(id==null)
            {
                return NotFound();
            }
        if(id!=productTypes.Id)
            {
                return NotFound();
            }
            
            var productType = _db.ProductTypesController;
            if(productType==null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                //   _db.Add(productTypes);
                 _db.ProductTypesController.Remove(productTypes);
                await _db.SaveChangesAsync();
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(productTypes);
        }
    }


    
}
