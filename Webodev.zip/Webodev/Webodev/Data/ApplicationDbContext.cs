﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Webodev.Models;

namespace Webodev.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<ProductTypes> ProductTypesController { get; set;  }
        

        internal void Add(object ProductTypesController)
        {
            throw new NotImplementedException();
        }
            
        internal Task GetProductTypesController(object iD)
        {
            throw new NotImplementedException();
        }
        public DbSet<SpecialTag> SpecialTagController { get; set; }
        internal void Add1(object SpecialTagController)
        {
            throw new NotImplementedException();
        }
        internal Task GetSpecialTagController(object iD)
        {
            throw new NotImplementedException();
        }
        public DbSet<Products> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }
        public DbSet<ApplicationUser>ApplicationUsers { get; set; }

    }


}
